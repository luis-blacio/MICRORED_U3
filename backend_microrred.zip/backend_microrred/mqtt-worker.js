const mqtt = require('mqtt');
const { Pool } = require('pg');

// --- CONFIGURACIÓN DE BASE DE DATOS ---
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'microrred_db',
    password: 'admin123', 
});

// --- CONFIGURACIÓN DE MQTT ---
const mqttClient = mqtt.connect('mqtt://127.0.0.1:1883');
const topic = 'energia/oferta';

mqttClient.on('connect', () => {
    console.log('✅ Conectado a Mosquitto MQTT');
    mqttClient.subscribe(topic, (err) => {
        if (!err) {
            console.log(`📡 Escuchando el tópico: ${topic}\n`);
        }
    });
});

// --- LÓGICA DE PROCESAMIENTO ---
mqttClient.on('message', async (topic, message) => {
    try {
        // 1. Convertir el texto recibido a un objeto JSON
        const payload = JSON.parse(message.toString());
        console.log('📥 Nuevo mensaje recibido:', payload);

        // 2. Preparar la consulta SQL
        // Si energia_disponible no viene en el JSON (ej. de los nodos receptor/gateway), se guarda como null
        const query = `
            INSERT INTO historial_eventos (nodo, evento, energia_disponible) 
            VALUES ($1, $2, $3)
        `;
        const values = [
            payload.nodo, 
            payload.evento, 
            payload.energia_disponible || null
        ];

        // 3. Insertar en PostgreSQL
        await pool.query(query, values);
        console.log('💾 ¡Guardado en PostgreSQL exitosamente!\n');

    } catch (error) {
        console.error('❌ Error procesando el mensaje:', error);
    }
});