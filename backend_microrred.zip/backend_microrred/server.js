const express = require('express');
const { Pool } = require('pg');
const mqtt = require('mqtt');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// --- 1. CONFIGURACIÓN DE BASE DE DATOS ---
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'microrred_db',
    password: 'admin123', // Tu contraseña de PostgreSQL
    port: 5432,
});

// --- 2. CONFIGURACIÓN DE MQTT ---
const mqttClient = mqtt.connect('mqtt://127.0.0.1:1883');
const topicOferta = 'energia/oferta';
const topicAceptacion = 'energia/aceptacion';

mqttClient.on('connect', () => {
    console.log('✅ Conectado a Mosquitto MQTT');
    mqttClient.subscribe(topicOferta, (err) => {
        if (!err) console.log(`📡 Escuchando ofertas en: ${topicOferta}`);
    });
});

// Guardar en DB cuando llega un mensaje de los ESP32
mqttClient.on('message', async (topic, message) => {
    if (topic === topicOferta) {
        try {
            const payload = JSON.parse(message.toString());
            const query = `INSERT INTO historial_eventos (nodo, evento, energia_disponible) VALUES ($1, $2, $3)`;
            const values = [payload.nodo, payload.evento, payload.energia_disponible || null];
            await pool.query(query, values);
            console.log('💾 Evento guardado:', payload.evento);
        } catch (error) {
            console.error('❌ Error procesando MQTT:', error);
        }
    }
});

// --- 3. CONFIGURACIÓN DEL SERVIDOR WEB (EXPRESS) ---

// Servir la carpeta "public" donde está el HTML
app.use(express.static(path.join(__dirname, 'public')));

// Endpoint: Enviar los últimos 20 eventos al Dashboard
app.get('/api/eventos', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM historial_eventos ORDER BY fecha_hora DESC LIMIT 20');
        res.json(result.rows);
    } catch (error) {
        res.status(500).json({ error: 'Error al consultar la base de datos' });
    }
});

// Endpoint: Recibir clic del botón del Dashboard y enviar a MQTT
app.post('/api/aceptar', (req, res) => {
    const comando = JSON.stringify({ evento: "ACEPTADA" });
    mqttClient.publish(topicAceptacion, comando);
    console.log('🚀 Comando ACEPTADA enviado desde el Dashboard');
    res.json({ success: true, mensaje: "Comando enviado al Gateway" });
});

// Iniciar el servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`\n🌐 =========================================`);
    console.log(`🚀 DASHBOARD ACTIVO: http://localhost:${PORT}`);
    console.log(`🌐 =========================================\n`);
});